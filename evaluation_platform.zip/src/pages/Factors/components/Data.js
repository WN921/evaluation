import { useState, useEffect } from "react";

import { Menu, Row, Col, Radio, Card, Input, message, Popconfirm } from "antd";

import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { List, Avatar, Button } from "antd";
import { source_upload, source_selectall_name, source_delete } from "../../../api/api";

const { TextArea } = Input;
const data = [
  {
    title: "数据1",
  },
  {
    title: "数据2",
  },
  {
    title: "数据3",
  },
];
const params = ["参数1", "参数2", "参数3", "参数4", "参数5", "参数6"];

function Data(props) {
  const [file, setFile] = useState(null);
  const [sourceName, setSourceName] = useState("");
  const [objName, setObjName] = useState("");
  const [levelName, setLevelName] = useState("");
  const [sceneName, setSceneName] = useState("");
  const [sourceDesc, setSourceDesc] = useState("");
  const [sources, setSources] = useState([]);
  const [selectedId, setSelectedId] = useState(0);

  useEffect(() => {
    source_selectall_name().then(res => {
      console.log(res);
      if (res.status === 200) {
        setSources(res.data);
        message.success('load success');
      }
      else {
        message.error('uoload fail');
      }
    })
  }, [])
  const loadFile = (e) => {
    setFile(e.target.files[0]);
  };
  const upLoadFile = () => {
    source_upload(
      file,
      objName,
      levelName,
      sceneName,
      sourceName,
      sourceDesc
    ).then((res) => {
      if (res.status === 200) {
        message.success(res?.data);
        setSourceName(sourceName);
      } else {
        message.error("upload fail");
      }
    });
  };
  const confirm = (name) => {
    source_delete(name).then(res => {
      if (res.status === 200) {
        message.success(res.data);
      }
      else {
        message.error('delete fail');
      }
    })
  }
  return (
    <Row className="Row" gutter={16}>
      <Col span={6} className="Left">
        <Radio.Group value={selectedId} onChange={e => {
          setSelectedId(e.target.value);
          sources.forEach(item => {
            if (item.id === e.target.value) {
              setSourceName(item.accessname);
              setObjName(item.accessobject);
              setLevelName(item.accesslevel);
              setSceneName(item.accessscene);
              setSourceDesc(item.accessdesc);
            }
          })
        }}>
          <List
            style={{
              overflowY: "scroll",
              height: "50vh",
              marginTop: "2vh",
            }}
            itemLayout="horizontal"
            dataSource={sources}
            renderItem={(item, index) => (
              <List.Item>
                <List.Item.Meta
                  title={item.accessname}
                />
                <Popconfirm
                  title="Are you sure to delete this level?"
                  onConfirm={() => confirm(item.accessname)}
                  okText="Yes"
                  cancelText="No"
                >
                  <DeleteOutlined style={{ fontSize: 'x-large' }} />
                </Popconfirm>
                <Radio value={item.id} />
              </List.Item>
            )}
          />
        </Radio.Group>
        <Button
          block
          type="primary"
          style={{
            marginTop: "3vh",
          }}
          onClick={upLoadFile}
        >
          新增
        </Button>
      </Col>

      <Col span={18} className="Right">
        <Row>
          <Col span={12} className="Center">
            <Input
              placeholder="数据源名称"
              style={{
                width: "10vw",
              }}
              value={sourceName}
              onChange={(e) => {
                setSourceName(e.target.value);
              }}
            />
          </Col>
          <Col span={12} className="Center">
            <Input
              placeholder="数据对象名称"
              style={{
                width: "10vw",
              }}
              value={objName}
              onChange={(e) => {
                setObjName(e.target.value);
              }}
            />
          </Col>
        </Row>
        <Row
          style={{
            margin: "5vh 0",
          }}
        >
          <Col span={12} className="Center">
            <Input
              placeholder="等级"
              style={{
                width: "10vw",
              }}
              value={levelName}
              onChange={(e) => {
                setLevelName(e.target.value);
              }}
            />
          </Col>
          <Col span={12} className="Center">
            <Input
              placeholder="场景"
              style={{
                width: "10vw",
              }}
              value={sceneName}
              onChange={(e) => {
                setSceneName(e.target.value);
              }}
            />
          </Col>
        </Row>
        <Row gutter={32}>
          <Col
            span={24}
            style={{
              display: "flex",
              justifyContent: "center",
              alignContent: "center",
            }}
          >
            <Card bordered={false} style={{ width: "30vw", margin: "5vh 0" }}>
              <p>{`数据源描述信息：`}</p>
              <TextArea
                rows={10}
                value={sourceDesc}
                onChange={(e) => {
                  setSourceDesc(e.target.value);
                }}
              />
            </Card>
            <input type='file' onChange={loadFile} />
          </Col>
        </Row>
      </Col>
    </Row>
  );
}

export default Data;
